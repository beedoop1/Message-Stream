﻿namespace p5;

public interface ISubscriber
{
    void NewMessage(string message);
}