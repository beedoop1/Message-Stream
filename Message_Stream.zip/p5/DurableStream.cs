﻿/* Class Invariants
 * Messages are loaded from the file during initialization
 * Reset restores the file to original state
 *
 * DurableStream inherits from MsgStream and extends functionality
 */
namespace p5;

public class DurableStream : MsgStream, IDisposable
{ 
    private string fileName;
    private string[] lines;
    // private int bufferSize;
    
    public DurableStream(int maxCapacity, int maxOperation, string fileName) : base(maxCapacity, maxOperation)
    {
        this.fileName = fileName;
        // bufferSize = 0;

        if (File.Exists(fileName))
        {
            lines = File.ReadAllLines(fileName);
            for (int i = 0; i < lines.Length; i++)
            {
                base.AppendMessages(lines[i]);
            }
            // currentCapacity = lines.Length;
        }
        else
        {
            lines = new string[0];
        }
    }

    public override DurableStream DeepCopy()
    {
        string newFileName = "newFile.txt";
        File.Copy(fileName, newFileName);
        DurableStream copy = new DurableStream(maxCapacity, maxOperation, newFileName);

        // copy.listOfMessages = new string[listOfMessages.Length];
        //
        // for (int i = 0; i < currentCapacity; i++)
        // {
        //     copy.listOfMessages[i] = listOfMessages[i];
        // }

        copy.listOfMessages = (string[])listOfMessages.Clone();
        copy.currentCapacity = currentCapacity;
        copy.currentOperation = currentOperation;

        return copy;
    }

    public override void AppendMessages(string msg)
    {
        base.AppendMessages(msg);


        File.AppendAllText(fileName, msg + "\n");
    }

    public override void Reset()
    {
        base.Reset();

        listOfMessages = new string[lines.Length];
        for (int i = 0; i < lines.Length; i++)
        {
            listOfMessages[i] = lines[i];
        }
        currentCapacity = lines.Length;
        
        File.WriteAllLines(fileName, lines);
    }

    public void Dispose()
    {
        if (File.Exists(fileName))
        {
            File.Delete(fileName);
        }
    }
}