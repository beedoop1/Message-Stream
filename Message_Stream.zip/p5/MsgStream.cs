﻿/* Class Invariants
 * The message count is expected to never exceed the maximum capacity
 * The number of operations is expected to not exceed the maximum operations
 * The range of messages to read is expected to be valid:
 *  - start index is not less than 0
 *  - the end index is greater than or equal to the current amount of messages
 *  - end index is greater than start
 * All messages appended are expected to be not null or an empty string
 * When the reset is called, the numbers are expected to change back to what they were set at the start of the operations
*/
namespace p5;

// Dependency Injection
public interface IMsgStream
{
    public IMsgStream DeepCopy();
    public void AppendMessages(string message);
    public string[] ReadMessages(int start, int end);
    public void Reset();
    public int GetMessageCount();
    public int GetRemainingCapacity();
    public int GetRemainingOperations();
}

public class MsgStream : IMsgStream
{
    protected string[] listOfMessages;
    protected int maxCapacity;
    protected int currentCapacity;
    protected int maxOperation;
    protected int currentOperation;
    
    public MsgStream(int maxCapacity, int maxOperation)
    {
        listOfMessages = new string[maxCapacity];
        this.maxCapacity = maxCapacity;
        currentCapacity = 0;
        this.maxOperation = maxOperation;
        currentOperation = 0;
    }
    
    public virtual IMsgStream DeepCopy()
    {
        MsgStream copy = (MsgStream)MemberwiseClone();
        // copy.listOfMessages = new string[maxCapacity];
        copy.listOfMessages = (string[])listOfMessages.Clone();

        // for (int i = 0; i < currentCapacity; i++)
        // {
        //     copy.listOfMessages[i] = listOfMessages[i];
        // }

        return copy;
    }

    /*
     * Preconditions:
     * the capacity is in bounds
     * the amount of operations is in bounds
     * the msg parameter must not be null or empty
     *
     * Postconditions:
     * message is appended into the right index of the array
     * the capacity is incremented by 1
     * the amount of operations is incremented by 1
     */
    public virtual void AppendMessages(string message)
    {
        CheckCapacity();
        CheckOperation();
        
        if (string.IsNullOrEmpty(message))
        {
            throw new ArgumentException("Use non-null message or empty");
        }

        listOfMessages[currentCapacity] = message;
        currentCapacity++;
        currentOperation++;
    }

    /* Preconditions:
     * the amount of operations is in bounds
     * the start and end indices are in bounds: start >= 0, end < currentCapacity, end > start
     *
     * Postconditions:
     * a new array of type string is formed and a size is set to the array
     * the messages are appended to the array
     * operation is incremented by 1
     */
    public string[] ReadMessages(int start, int end)
    {
        CheckOperation();
        
        if (start < 0 || end < 0)
            throw new ArgumentOutOfRangeException("Use non-negative values");

        if (start < 0 || end >= currentCapacity || start > end)
        {
            throw new ArgumentOutOfRangeException("Invalid range");
        }
        
        string[] messagesInRange = new string[end - start + 1];
        for (int i = 0; i < messagesInRange.Length; i++)
        {
            messagesInRange[i] = listOfMessages[start + i];
        }

        currentOperation++;
        return messagesInRange;
    }

    /*
     * Postconditions:
     * the list of strings is reinitialized to the size of the max capacity
     * current capacity and operations are both reset to 0
     */
    public virtual void Reset()
    {
        listOfMessages = new string[maxCapacity];
        currentCapacity = 0;
        currentOperation = 0;
    }

    public int GetMessageCount()
    {
        return currentCapacity;
    }
    
    public int GetRemainingCapacity()
    {
        return maxCapacity - currentCapacity;
    }

    public int GetRemainingOperations()
    {
        return maxOperation - currentOperation;
    }

    /*
     * Precondition - current capacity is greater than or equal to the max capacity
     * Postcondition - exception is thrown 
     */
    private void CheckCapacity()
    {
        if (currentCapacity >= maxCapacity)
        {
            throw new InvalidOperationException("Maximum Capacity Exceeded");
        }
    }

    /*
     * Precondition - current operation is greater than or equal to the max operation
     * Postcondition - exception is thrown
     */
    private void CheckOperation()
    {
        if (currentOperation >= maxOperation)
        {
            throw new InvalidOperationException("Operation Limit Reached");
        }
    }
}

/* Implementation Invariant
 Array (listOfMessages) is a fixed value set by the max capacity
 Messages are stored in the array
 Message Count (currentCapacity) is incremented every time a message is appended successfully
 Operation Count (currentOperation) is incremented every time a message is appended or user reads messages successfully
*/
