﻿/* Class Invariants
 * The length of msgStreams is always the same as partitionKeys and partitionCount
 * partitionKeys must not contain duplicate keys
 * msgStream elements are expected to be not null or an empty string
 */
namespace p5;

public class PartitionStream
{
    private IMsgStream[] msgStreams;
    private string[] partitionKeys;
    private int partitionCount;

    
    public PartitionStream(IMsgStream[] msgStreams, string[] partitionKeys, int partitionCount)
    {
        if (msgStreams.Length != partitionKeys.Length || msgStreams.Length != partitionCount)
        {
            throw new ArgumentException("The number of streams and the number of partitions must be the same.");
        }

        for (int i = 0; i < partitionKeys.Length; i++)
        {
            for (int j = 0; j < partitionKeys.Length; j++)
            {
                if (partitionKeys[i] == partitionKeys[j])
                {
                    throw new ArgumentException("The stream number is already in this partition.");
                }
            }
        }
        
        this.msgStreams = msgStreams;
        this.partitionKeys = partitionKeys;
        this.partitionCount = partitionCount;
    }

    public PartitionStream DeepCopy()
    {
        IMsgStream[] newMsgStreams = new IMsgStream[partitionCount];
        string[] newPartitionKeys = new string[partitionCount];

        for (int i = 0; i < partitionCount; i++)
        {
            newMsgStreams[i] = msgStreams[i].DeepCopy();
        }

        for (int i = 0; i < partitionCount; i++)
        {
            newPartitionKeys[i] = partitionKeys[i];
        }
        
        return new PartitionStream(newMsgStreams, newPartitionKeys, partitionCount);
    }

    /*
     * Preconditions:
     * there is a partition key that matches one stored in the partitionKeys array
     *
     * Postconditions:
     * the message is appended to the MsgStream if there is a matching partition key
     */
    public void WriteMessage(string message, string partitionKey)
    {
        for (int i = 0; i < partitionCount; i++) 
        {
            if (partitionKeys[i] == partitionKey) 
            {
                msgStreams[i].AppendMessages(message);
                return;
            }
        }
        throw new ArgumentException("Partition Key is not found");
    }

    /*
     * Preconditions:
     * the partition key is in bounds
     * there is a partition key that matches one stored in the partitionKeys array
     *
     * Postconditions:
     * an array of messages from start to end will be returned if partition key matches
     */
    public string[] ReadMessages(string partitionKey, int start, int end)
    {
        for (int i = 0; i < partitionCount; i++)
        {
            if (partitionKeys[i] == partitionKey)
            {
                int messageCount = msgStreams[i].GetMessageCount();
                if (start < 0 || end >= messageCount || start >= end)
                {
                    throw new ArgumentOutOfRangeException("Invalid range");
                }
                return msgStreams[i].ReadMessages(start, end);
            }
        }
        throw new ArgumentException("Partition Key is Not Found");
    }

    /*
     * Postconditions:
     * msgStreams are reset to their initial state
     * paritionKeys is cleared and and new array is set to the same size
     */
    public void Reset()
    {
        for (int i = 0; i < partitionCount; i++)
            msgStreams[i].Reset();
        partitionKeys = new string[partitionCount];
    }
}